"""
News Parser Package
""" 