# This file makes the news_parser directory a Python package
